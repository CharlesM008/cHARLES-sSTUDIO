(() => {
  'use strict';

  // ---------- tiny helpers ----------
  const $ = (sel, root = document) => root.querySelector(sel);
  const peso = (n) => '₱' + Number(n).toLocaleString('en-PH', { minimumFractionDigits: Number.isInteger(Number(n)) ? 0 : 2, maximumFractionDigits: 2 });
  const fmtDate = (iso) => new Date(iso).toLocaleString('en-PH', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Manila' });

  // Build DOM safely: text is always set via textContent, never innerHTML.
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === false || v == null) continue;
      if (k === 'class') el.className = v;
      else if (k === 'on') for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
      else if (k === 'text') el.textContent = v;
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }

  async function api(path, opts = {}) {
    const res = await fetch('/api' + path, opts);
    let data = {};
    try { data = await res.json(); } catch { /* non-json */ }
    if (!res.ok) { const e = new Error(data.error || 'Something went wrong. Please try again.'); e.field = data.field; e.status = res.status; throw e; }
    return data;
  }

  function toast(msg, link) {
    const t = h('div', { class: 'toast' }, h('span', { text: msg }), link ? h('a', { href: link.href, text: link.text }) : null);
    $('#toasts').append(t);
    setTimeout(() => t.remove(), 4200);
  }

  // ---------- state ----------
  const state = { shop: null, products: [], sig: '', category: 'All', q: '', sort: 'new', loaded: false };
  const CART_KEY = 'cart.v1';
  const getCart = () => { try { const c = JSON.parse(localStorage.getItem(CART_KEY) || '[]'); return Array.isArray(c) ? c.map(Number).filter(Boolean) : []; } catch { return []; } };
  const setCart = (ids) => { try { localStorage.setItem(CART_KEY, JSON.stringify([...new Set(ids)])); } catch { /* ignore */ } updateCartCount(); };
  const productById = (id) => state.products.find((p) => p.id === Number(id));

  function updateCartCount(bump) {
    const n = getCart().length;
    const el = $('#cartCount');
    el.textContent = n; el.hidden = n === 0;
    if (bump) { el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump'); }
  }

  // ---------- data loading (auto-refresh so admin edits appear without reloading) ----------
  async function loadShop() {
    state.shop = await api('/shop');
    document.title = state.shop.shop_name;
    $('#brand').textContent = state.shop.shop_name;
    $('#footName').textContent = state.shop.shop_name;
    $('#footContact').textContent = state.shop.contact_email ? `Questions? ${state.shop.contact_email}` : '';
  }
  async function loadProducts() {
    const { products } = await api('/products');
    const sig = JSON.stringify(products.map((p) => [p.id, p.name, p.price, p.available, p.description, p.category, p.images.map((i) => i.id), p.updated_at]));
    const changed = sig !== state.sig;
    state.products = products; state.sig = sig; state.loaded = true;
    // drop anything from the cart that is no longer for sale
    const live = new Set(products.filter((p) => p.available).map((p) => p.id));
    const cart = getCart();
    if (state.loaded && cart.some((id) => !live.has(id))) setCart(cart.filter((id) => live.has(id)));
    return changed;
  }
  async function refresh() {
    try {
      const [changed] = await Promise.all([loadProducts(), loadShop()]);
      const route = parseRoute().name;
      // never re-render while someone is typing in a form
      const typing = document.activeElement && ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName);
      if (changed && !typing && ['home', 'product', 'cart'].includes(route)) render();
    } catch { /* offline: keep what is on screen */ }
  }
  setInterval(() => { if (!document.hidden) refresh(); }, 15000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });

  // ---------- router ----------
  function parseRoute() {
    const hash = location.hash.replace(/^#/, '') || '/';
    const parts = hash.split('?')[0].split('/').filter(Boolean);
    if (!parts.length) return { name: 'home' };
    if (parts[0] === 'product') return { name: 'product', id: parts[1] };
    if (parts[0] === 'order') return { name: 'order', code: decodeURIComponent(parts[1] || '') };
    if (['cart', 'checkout', 'about', 'track'].includes(parts[0])) return { name: parts[0] };
    return { name: 'home' };
  }
  function setNav(name) {
    document.querySelectorAll('[data-nav]').forEach((a) => {
      const on = a.dataset.nav === name || (a.dataset.nav === 'home' && ['product', 'cart', 'checkout'].includes(name));
      if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
  }
  let renderToken = 0;
  async function render(scrollTop = false) {
    const token = ++renderToken;
    const route = parseRoute();
    setNav(route.name);
    const main = $('#main');
    if (!state.loaded) {
      main.replaceChildren(h('div', { class: 'wrap page' }, h('div', { class: 'grid' }, [1, 2, 3, 4].map(() => h('div', { class: 'skeleton' })))));
      try { await Promise.all([loadShop(), loadProducts()]); } catch (e) { main.replaceChildren(h('div', { class: 'wrap empty' }, h('h2', { text: 'The shop could not load' }), h('p', { text: 'Check your connection and refresh the page.' }))); return; }
      if (token !== renderToken) return;
    }
    const views = { home: viewHome, product: viewProduct, cart: viewCart, checkout: viewCheckout, about: viewAbout, track: viewTrack, order: viewOrder };
    const view = await views[route.name](route);
    if (token !== renderToken) return;
    main.replaceChildren(view);
    if (scrollTop) { window.scrollTo(0, 0); }
  }
  window.addEventListener('hashchange', () => render(true));

  // ---------- views ----------
  function artImg(p, cls) {
    const img = p.images[0];
    return img ? h('img', { src: img.url, alt: p.name, loading: 'lazy', class: cls }) : h('div', { class: 'ph c0', 'aria-hidden': 'true', text: p.name.slice(0, 1).toUpperCase() });
  }

  function viewHome() {
    const s = state.shop;
    const withImg = state.products.filter((p) => p.images.length).slice(0, 3);
    const wall = h('div', { class: 'wall', 'aria-hidden': 'true' },
      [0, 1, 2].map((i) => {
        const p = withImg[i];
        return h('div', { class: `sheet s${i + 1}` }, p ? h('img', { src: p.images[0].url, alt: '' }) : h('div', { class: `ph c${i}`, text: ['A', 'B', 'C'][i] }));
      }));

    const hero = h('section', { class: 'hero' }, h('div', { class: 'wrap hero-grid' },
      h('div', {},
        h('h1', { text: s.tagline && s.tagline.length < 60 ? s.tagline : 'Original designs, ready to download.' }),
        h('p', { class: 'lead', text: s.tagline && s.tagline.length >= 60 ? s.tagline : 'Browse posters, logos, story designs and pubmats. Pay with GCash, Maya or MariBank.' }),
        h('div', { class: 'cta' },
          h('a', { class: 'btn', href: '#catalog', on: { click: (e) => { e.preventDefault(); $('#catalog').scrollIntoView({ behavior: 'smooth' }); } }, text: 'Browse designs' }),
          h('a', { class: 'btn ghost', href: '#/about', text: 'About the studio' }))),
      wall));

    const cats = ['All', ...s.categories.filter((c) => c.count > 0).map((c) => c.name)];
    if (!cats.includes(state.category)) state.category = 'All';

    const grid = h('div', { class: 'grid', id: 'grid' });
    const chips = h('div', { class: 'chips', role: 'group', 'aria-label': 'Filter by category' });

    function paint() {
      let list = state.products.filter((p) => (state.category === 'All' || p.category === state.category));
      const q = state.q.trim().toLowerCase();
      if (q) list = list.filter((p) => (p.name + ' ' + p.description + ' ' + (p.category || '')).toLowerCase().includes(q));
      if (state.sort === 'low') list.sort((a, b) => a.price - b.price);
      else if (state.sort === 'high') list.sort((a, b) => b.price - a.price);
      grid.replaceChildren(...(list.length ? list.map(card) : [h('div', { class: 'empty', style: 'grid-column:1/-1' },
        h('h2', { text: state.products.length ? 'No designs match your search' : 'No designs yet' }),
        h('p', { text: state.products.length ? 'Try a different word or pick another category.' : 'New work is on the way. Check back soon.' }))]));
      chips.replaceChildren(...cats.map((c) => {
        const n = c === 'All' ? state.products.length : state.products.filter((p) => p.category === c).length;
        return h('button', { class: 'chip', type: 'button', 'aria-pressed': String(state.category === c), on: { click: () => { state.category = c; paint(); } } }, c, h('small', { text: n }));
      }));
    }

    const search = h('input', { type: 'search', placeholder: 'Search designs', 'aria-label': 'Search designs', value: state.q, on: { input: (e) => { state.q = e.target.value; paint(); } } });
    const sort = h('select', { 'aria-label': 'Sort', on: { change: (e) => { state.sort = e.target.value; paint(); } } },
      [['new', 'Newest'], ['low', 'Price: low to high'], ['high', 'Price: high to low']].map(([v, t]) => h('option', { value: v, selected: state.sort === v, text: t })));
    paint();

    return h('div', {}, hero, h('div', { class: 'wrap', id: 'catalog' }, h('div', { class: 'toolbar' }, chips, h('div', { class: 'tools' }, search, sort)), grid));
  }

  function card(p) {
    return h('a', { class: 'item', href: `#/product/${p.id}` },
      h('div', { class: 'art' }, artImg(p), p.available ? null : h('span', { class: 'tag', text: 'Unavailable' })),
      h('div', { class: 'row' }, h('h3', { text: p.name }), h('span', { class: 'price', text: peso(p.price) })),
      p.category ? h('p', { class: 'cat', text: p.category }) : null);
  }

  function viewProduct(route) {
    const p = productById(route.id);
    if (!p) return h('div', { class: 'wrap empty' }, h('h2', { text: 'This design is no longer available' }), h('a', { class: 'btn', href: '#/', text: 'Back to the shop' }));
    document.title = `${p.name} – ${state.shop.shop_name}`;
    const main = h('div', { class: 'main' }, p.images[0] ? h('img', { src: p.images[0].url, alt: p.name }) : h('div', { class: 'ph c0', text: p.name.slice(0, 1).toUpperCase() }));
    const thumbs = h('div', { class: 'thumbs' }, p.images.length > 1 ? p.images.map((img, i) => h('button', { type: 'button', 'aria-label': `View image ${i + 1}`, 'aria-current': String(i === 0), on: { click: (e) => {
      main.replaceChildren(h('img', { src: img.url, alt: p.name }));
      thumbs.querySelectorAll('button').forEach((b) => b.setAttribute('aria-current', 'false'));
      e.currentTarget.setAttribute('aria-current', 'true');
    } } }, h('img', { src: img.url, alt: '' }))) : []);

    const inCart = () => getCart().includes(p.id);
    const addBtn = h('button', { class: 'btn', type: 'button', disabled: !p.available });
    const paint = () => { addBtn.textContent = !p.available ? 'Currently unavailable' : inCart() ? 'In your cart' : 'Add to cart'; addBtn.disabled = !p.available || inCart(); };
    addBtn.addEventListener('click', () => { setCart([...getCart(), p.id]); updateCartCount(true); paint(); toast(`${p.name} added to your cart`, { href: '#/cart', text: 'View cart' }); });
    paint();
    const buyNow = h('a', { class: 'btn ghost', href: '#/checkout', on: { click: () => { if (!inCart() && p.available) setCart([...getCart(), p.id]); } }, text: 'Buy now' });
    if (!p.available) buyNow.hidden = true;

    return h('div', { class: 'wrap' },
      h('p', { class: 'crumbs' }, h('a', { href: '#/', text: 'Shop' }), p.category ? ` / ${p.category}` : '', ` / ${p.name}`),
      h('div', { class: 'detail' },
        h('div', { class: 'gallery' }, main, thumbs),
        h('div', { class: 'info' },
          p.category ? h('p', { class: 'cat', text: p.category }) : null,
          h('h1', { text: p.name }),
          h('p', { class: 'price', text: peso(p.price) }),
          p.description ? h('p', { class: 'desc', text: p.description }) : null,
          h('div', { class: 'actions' }, addBtn, buyNow),
          h('div', { class: 'facts' },
            h('div', {}, h('b', { text: 'Delivery' }), h('span', { text: 'Digital files, sent after your payment is verified.' })),
            h('div', {}, h('b', { text: 'Payment' }), h('span', { text: 'GCash, Maya or MariBank.' }))))));
  }

  function cartLines() { return getCart().map(productById).filter((p) => p && p.available); }
  const cartTotal = () => cartLines().reduce((s, p) => s + p.price, 0);

  function viewCart() {
    const lines = cartLines();
    if (!lines.length) return h('div', { class: 'wrap page' }, h('h1', { text: 'Your cart' }), h('div', { class: 'empty' }, h('h2', { text: 'Your cart is empty' }), h('p', { text: 'Pick a design you like and it will show up here.' }), h('p', {}, h('a', { class: 'btn', href: '#/', text: 'Browse designs' }))));
    return h('div', { class: 'wrap page' }, h('h1', { text: 'Your cart' }),
      h('div', { class: 'cart-grid' },
        h('div', {}, lines.map((p) => h('div', { class: 'line' },
          h('a', { href: `#/product/${p.id}` }, p.images[0] ? h('img', { src: p.images[0].url, alt: p.name }) : h('div', { class: 'thumb' })),
          h('div', {}, h('h3', { text: p.name }), h('p', { class: 'muted', text: p.category || 'Digital design' }), h('button', { class: 'rm', type: 'button', text: 'Remove', on: { click: () => { setCart(getCart().filter((id) => id !== p.id)); render(); } } })),
          h('div', { class: 'price', text: peso(p.price) })))),
        h('aside', { class: 'summary' },
          h('div', { class: 'total' }, h('span', { text: `Total (${lines.length} ${lines.length === 1 ? 'item' : 'items'})` }), h('strong', { text: peso(cartTotal()) })),
          h('small', { text: 'Each design is a digital file. You will pay in Philippine pesos.' }),
          h('a', { class: 'btn block', href: '#/checkout', text: 'Continue to checkout' }),
          h('a', { class: 'btn ghost block', href: '#/', text: 'Keep browsing' }))));
  }

  function viewCheckout() {
    const lines = cartLines();
    if (!lines.length) return viewCart();
    const pays = state.shop.payments;
    let method = 'gcash';
    let file = null;

    const errBox = h('div', { class: 'form-error', hidden: true, role: 'alert' });
    const input = (name, label, attrs = {}, hint) => {
      const err = h('span', { class: 'err', 'data-err': name });
      return h('label', { class: 'field' }, h('span', {}, label, hint ? h('small', { text: ` ${hint}` }) : null), h('input', { name, ...attrs }), err);
    };
    const form = h('form', { novalidate: true, autocomplete: 'on' });

    const payBox = h('div');
    const refInput = h('input', { name: 'reference_number', placeholder: 'e.g. 1234 567 890123', maxlength: 60, autocomplete: 'off' });
    const refErr = h('span', { class: 'err', 'data-err': 'reference_number' });
    const preview = h('div');
    const fileInput = h('input', { type: 'file', name: 'receipt', accept: 'image/png,image/jpeg,image/webp' });
    const fileErr = h('span', { class: 'err', 'data-err': 'receipt' });
    const drop = h('label', { class: 'drop' }, h('strong', { text: 'Upload your receipt screenshot' }), h('span', { class: 'muted', text: 'JPG, PNG or WebP, up to 6 MB' }), fileInput, preview);

    function showFile(f) {
      file = f; preview.replaceChildren();
      if (!f) return;
      if (f.size > 6 * 1024 * 1024) { fileErr.textContent = 'That image is over 6 MB.'; file = null; return; }
      fileErr.textContent = '';
      const url = URL.createObjectURL(f);
      preview.append(h('img', { src: url, alt: 'Receipt preview', on: { load: () => URL.revokeObjectURL(url) } }), h('span', { class: 'muted', text: f.name }));
    }
    fileInput.addEventListener('change', () => showFile(fileInput.files[0] || null));
    ['dragover', 'dragenter'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, () => drop.classList.remove('over')));
    drop.addEventListener('drop', (e) => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) { const dt = new DataTransfer(); dt.items.add(f); fileInput.files = dt.files; showFile(f); } });

    function paintPay() {
      const p = pays[method];
      const steps = (p.instructions || '').split(/\n+/).filter(Boolean);
      payBox.replaceChildren(h('div', { class: `pay-box${p.qr_url ? '' : ' noqr'}` },
        h('div', {},
          h('p', { class: 'muted', text: `Send ${peso(cartTotal())} to ${p.label}` }),
          p.account_number ? h('p', { class: 'acct', text: p.account_number }) : h('p', { class: 'acct', text: 'Account number coming soon' }),
          p.account_name ? h('p', { text: p.account_name }) : null,
          steps.length ? h('ol', {}, steps.map((s) => h('li', { text: s }))) : null,
          h('p', { class: 'warn', text: 'Send the exact total. Your order stays unpaid until it is checked by hand.' })),
        p.qr_url ? h('img', { class: 'qr', src: p.qr_url, alt: `${p.label} QR code` }) : null));
    }

    const methodsEl = h('div', { class: 'methods', role: 'radiogroup', 'aria-label': 'Payment method' }, Object.entries(pays).map(([key, p]) =>
      h('label', { class: 'method' }, h('input', { type: 'radio', name: 'payment_method', value: key, checked: key === method, on: { change: () => { method = key; paintPay(); } } }), h('div', { class: 'tile', text: p.label }))));
    paintPay();

    const submit = h('button', { class: 'btn block', type: 'submit', text: `Place order · ${peso(cartTotal())}` });

    form.append(
      h('fieldset', { class: 'fieldset' }, h('legend', { text: 'Your details' }),
        input('customer_name', 'Full name', { autocomplete: 'name', required: true, maxlength: 100 }),
        h('div', { class: 'two' },
          input('email', 'Email', { type: 'email', autocomplete: 'email', required: true, maxlength: 160 }, '(we use it to find your order)'),
          input('phone', 'Contact number', { type: 'tel', autocomplete: 'tel', required: true, maxlength: 25, placeholder: '0917 123 4567' })),
        h('label', { class: 'field' }, h('span', {}, 'Notes ', h('small', { text: '(optional)' })), h('textarea', { name: 'notes', rows: 2, maxlength: 500, placeholder: 'Preferred file format, a name to print on the design, etc.' }))),
      h('fieldset', { class: 'fieldset' }, h('legend', { text: 'Payment method' }), methodsEl, payBox),
      h('fieldset', { class: 'fieldset' }, h('legend', { text: 'Proof of payment' }),
        h('p', { class: 'muted', text: 'Already paid? Add the reference number and a screenshot now. You can also place the order first and upload your proof later from the order page.' }),
        h('label', { class: 'field' }, h('span', {}, 'Reference number ', h('small', { text: '(from your receipt)' })), refInput, refErr),
        drop, fileErr),
      errBox, submit);

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      form.querySelectorAll('.err').forEach((x) => { x.textContent = ''; });
      form.querySelectorAll('[aria-invalid]').forEach((x) => x.removeAttribute('aria-invalid'));
      errBox.hidden = true;
      const fd = new FormData(form);
      fd.delete('receipt');
      if (file) fd.append('receipt', file);
      fd.set('items', JSON.stringify(lines.map((p) => p.id)));
      // quick client-side hints (the server validates everything again)
      const need = (k, msg) => { const el = form.elements[k]; if (!String(fd.get(k) || '').trim()) { markErr(k, msg); return false; } return true; };
      let ok = need('customer_name', 'Enter your full name.') & need('email', 'Enter your email address.') & need('phone', 'Enter your contact number.');
      if ((file || String(fd.get('reference_number') || '').trim()) && !(file && String(fd.get('reference_number') || '').trim())) {
        if (!file) markErr('receipt', 'Upload your receipt screenshot, or clear the reference number to upload later.');
        else markErr('reference_number', 'Enter the reference number from your receipt.');
        ok = false;
      }
      if (!ok) { const first = form.querySelector('.err:not(:empty)'); if (first) first.scrollIntoView({ block: 'center', behavior: 'smooth' }); return; }
      submit.disabled = true; submit.textContent = 'Placing your order…';
      try {
        const { order } = await api('/orders', { method: 'POST', body: fd });
        try { sessionStorage.setItem('order.' + order.code, String(fd.get('email')).trim().toLowerCase()); } catch { /* ignore */ }
        setCart([]);
        location.hash = `#/order/${order.code}`;
      } catch (err) {
        submit.disabled = false; submit.textContent = `Place order · ${peso(cartTotal())}`;
        if (err.field && markErr(err.field, err.message)) return;
        errBox.textContent = err.message; errBox.hidden = false; errBox.scrollIntoView({ block: 'center', behavior: 'smooth' });
      }
    });
    function markErr(name, msg) {
      const span = form.querySelector(`[data-err="${name}"]`);
      const el = form.elements[name];
      if (el && el.setAttribute) el.setAttribute('aria-invalid', 'true');
      if (span) { span.textContent = msg; return true; }
      return false;
    }

    return h('div', { class: 'wrap page' }, h('h1', { text: 'Checkout' }),
      h('div', { class: 'checkout-grid' }, form,
        h('aside', { class: 'summary' },
          h('h2', { class: 'legend', style: 'float:none;margin:0', text: 'Order summary' }),
          h('div', { class: 'mini-lines' }, lines.map((p) => h('div', {}, h('span', { text: p.name }), h('span', { text: peso(p.price) })))),
          h('div', { class: 'total' }, h('span', { text: 'Total to pay' }), h('strong', { text: peso(cartTotal()) })),
          h('a', { class: 'btn ghost block small', href: '#/cart', text: 'Edit cart' }))));
  }

  function viewAbout() {
    const s = state.shop;
    return h('div', { class: 'wrap page' }, h('h1', { text: `About ${s.shop_name}` }), h('p', { class: 'prose', text: s.about }),
      s.contact_email ? h('p', { class: 'prose', style: 'margin-top:20px', text: `Contact: ${s.contact_email}` }) : null);
  }

  function viewTrack() {
    const err = h('p', { class: 'err' });
    const form = h('form', { class: 'track-form', on: { submit: async (e) => {
      e.preventDefault(); err.textContent = '';
      const code = form.elements.code.value.trim().toUpperCase();
      const email = form.elements.email.value.trim().toLowerCase();
      if (!code || !email) { err.textContent = 'Enter your order code and email.'; return; }
      try { await api('/orders/lookup', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code, email }) }); sessionStorage.setItem('order.' + code, email); location.hash = `#/order/${code}`; }
      catch (ex) { err.textContent = ex.message; }
    } } },
      h('label', { class: 'field' }, h('span', { text: 'Order code' }), h('input', { name: 'code', placeholder: 'ORD-XXXXXXXX', autocomplete: 'off' })),
      h('label', { class: 'field' }, h('span', { text: 'Email used at checkout' }), h('input', { name: 'email', type: 'email', autocomplete: 'email' })),
      err, h('button', { class: 'btn', type: 'submit', text: 'Find my order' }));
    return h('div', { class: 'wrap page' }, h('h1', { text: 'Track your order' }), form);
  }

  const STATUS_CLASS = { 'Pending Payment': 's-pending', 'Payment Verification': 's-verify', Paid: 's-paid', Rejected: 's-rejected', Completed: 's-completed', Cancelled: 's-cancelled' };
  const STATUS_HELP = {
    'Pending Payment': 'We are waiting for your payment. Send the total, then upload your receipt below.',
    'Payment Verification': 'We received your proof of payment and will check it soon. This page updates when we do.',
    Paid: 'Your payment is confirmed. Your download links are below.',
    Rejected: 'We could not verify your payment. See the reason below and send new proof.',
    Completed: 'Your order is complete. Thank you!',
    Cancelled: 'This order was cancelled.',
  };

  async function viewOrder(route) {
    const code = route.code.toUpperCase();
    let email = ''; try { email = sessionStorage.getItem('order.' + code) || ''; } catch { /* ignore */ }
    if (!email) {
      location.hash = '#/track';
      return h('div');
    }
    let order;
    try { ({ order } = await api('/orders/lookup', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code, email }) })); }
    catch (e) { return h('div', { class: 'wrap page' }, h('h1', { text: 'Order not found' }), h('p', { class: 'prose', text: e.message }), h('p', { style: 'margin-top:20px' }, h('a', { class: 'btn', href: '#/track', text: 'Try again' }))); }

    document.title = `Order ${order.code}`;
    const panels = [];
    panels.push(h('div', { class: `notice${order.status === 'Rejected' || order.status === 'Cancelled' ? ' bad' : order.status === 'Paid' || order.status === 'Completed' ? ' ok' : ''}` },
      h('strong', { text: STATUS_HELP[order.status] }),
      order.status === 'Rejected' && order.reject_reason ? h('p', { text: `Reason: ${order.reject_reason}` }) : null));

    const links = order.items.filter((i) => i.delivery_url);
    if (['Paid', 'Completed'].includes(order.status)) {
      panels.push(h('section', { class: 'panel' }, h('h2', { text: 'Your files' }),
        links.length ? links.map((i) => h('div', { class: 'dl' }, h('span', { text: i.name }), h('a', { class: 'btn small', href: i.delivery_url, target: '_blank', rel: 'noopener noreferrer', text: 'Download' })))
          : h('p', { class: 'muted', text: 'Your files will be sent to your email shortly.' })));
    }

    if (['Pending Payment', 'Rejected'].includes(order.status)) {
      const p = state.shop.payments[order.payment_method];
      const errEl = h('div', { class: 'form-error', hidden: true, role: 'alert' });
      const fileInput = h('input', { type: 'file', name: 'receipt', accept: 'image/png,image/jpeg,image/webp', required: true });
      const form = h('form', { class: 'track-form', style: 'max-width:none', on: { submit: async (e) => {
        e.preventDefault(); errEl.hidden = true;
        const fd = new FormData(form); fd.set('email', email);
        const btn = form.querySelector('button'); btn.disabled = true; btn.textContent = 'Sending…';
        try { await api(`/orders/${order.code}/proof`, { method: 'POST', body: fd }); toast('Proof of payment sent'); render(); }
        catch (ex) { errEl.textContent = ex.message; errEl.hidden = false; btn.disabled = false; btn.textContent = 'Send proof of payment'; }
      } } },
        h('label', { class: 'field' }, h('span', { text: 'Reference number' }), h('input', { name: 'reference_number', required: true, maxlength: 60, autocomplete: 'off' })),
        h('label', { class: 'field' }, h('span', { text: 'Receipt screenshot' }), fileInput),
        errEl, h('button', { class: 'btn', type: 'submit', text: 'Send proof of payment' }));
      panels.push(h('section', { class: 'panel' }, h('h2', { text: `Pay with ${p.label}` }),
        h('p', {}, `Send ${peso(order.total)} to `, h('strong', { text: p.account_number || 'the account shown at checkout' }), p.account_name ? ` (${p.account_name})` : ''),
        p.qr_url ? h('img', { class: 'qr', style: 'width:150px;background:#fff;padding:6px;border-radius:8px', src: p.qr_url, alt: `${p.label} QR code` }) : null,
        form));
    }

    panels.push(h('section', { class: 'panel' }, h('h2', { text: 'Order details' }),
      order.items.map((i) => h('div', { class: 'dl' }, h('span', { text: i.name }), h('strong', { text: peso(i.price) }))),
      h('div', { class: 'dl' }, h('span', { text: 'Total' }), h('strong', { text: peso(order.total) })),
      h('div', { class: 'dl' }, h('span', { text: 'Payment method' }), h('span', { text: order.payment_method_label })),
      order.reference_number ? h('div', { class: 'dl' }, h('span', { text: 'Reference number' }), h('span', { text: order.reference_number })) : null,
      h('div', { class: 'dl' }, h('span', { text: 'Placed' }), h('span', { text: fmtDate(order.created_at) }))));

    return h('div', { class: 'wrap page' },
      h('h1', { text: order.status === 'Pending Payment' || order.status === 'Payment Verification' ? 'Thank you, ' + order.customer_name.split(' ')[0] : 'Your order' }),
      h('div', { class: 'order-head' }, h('span', { class: 'code', text: order.code }), h('span', { class: `badge ${STATUS_CLASS[order.status]}`, text: order.status }),
        h('span', { class: 'muted', text: 'Save your order code. You need it and your email to check this order later.' })),
      h('div', { style: 'max-width:760px' }, panels));
  }

  // ---------- theme ----------
  $('#themeBtn').addEventListener('click', () => {
    const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    try { localStorage.setItem('theme', next); } catch { /* ignore */ }
    $('#themeBtn').setAttribute('aria-label', next === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
  });
  $('#themeBtn').setAttribute('aria-label', document.documentElement.getAttribute('data-theme') === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');

  // ---------- boot ----------
  updateCartCount();
  render();
})();
