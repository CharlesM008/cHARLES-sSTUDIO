(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const peso = (n) => '₱' + Number(n).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString('en-PH', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Manila' }) : '–');
  const STATUSES = ['Pending Payment', 'Payment Verification', 'Paid', 'Rejected', 'Completed', 'Cancelled'];
  const SC = { 'Pending Payment': 's-pending', 'Payment Verification': 's-verify', Paid: 's-paid', Rejected: 's-rejected', Completed: 's-completed', Cancelled: 's-cancelled' };

  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === false || v == null) continue;
      if (k === 'class') el.className = v;
      else if (k === 'on') for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
      else if (k === 'text') el.textContent = v;
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
    for (const kid of kids.flat()) { if (kid == null || kid === false) continue; el.append(kid.nodeType ? kid : document.createTextNode(String(kid))); }
    return el;
  }
  const svg = (tag, attrs = {}, ...kids) => {
    const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
    kids.flat().forEach((k) => k && el.append(k.nodeType ? k : document.createTextNode(k)));
    return el;
  };

  class AuthError extends Error {}
  async function api(path, { method = 'GET', json, form } = {}) {
    const opts = { method, headers: {}, credentials: 'same-origin' };
    if (json) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(json); }
    if (form) opts.body = form;
    const res = await fetch('/admin/api' + path, opts);
    let data = {};
    try { data = await res.json(); } catch { /* ignore */ }
    if (res.status === 401 && path !== '/login') { showLogin(); throw new AuthError('signed out'); }
    if (!res.ok) { const e = new Error(data.error || 'Something went wrong.'); e.field = data.field; throw e; }
    return data;
  }
  function toast(msg, bad) {
    const t = h('div', { class: `toast${bad ? ' bad' : ''}`, text: msg });
    $('#toasts').append(t); setTimeout(() => t.remove(), 3800);
  }
  const guard = (fn) => async (...a) => { try { return await fn(...a); } catch (e) { if (!(e instanceof AuthError)) toast(e.message, true); } };

  // ---------- small dialogs ----------
  function modal(title, body, footer, { wide } = {}) {
    const dlg = h('dialog', { 'aria-label': title });
    if (wide) dlg.style.width = 'min(860px, 100% - 24px)';
    const close = () => { dlg.close(); };
    dlg.append(h('div', { class: 'dlg-head' }, h('h2', { text: title }), h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Close', text: '✕', on: { click: close } })), body, footer || '');
    dlg.addEventListener('close', () => dlg.remove());
    dlg.addEventListener('click', (e) => { if (e.target === dlg) close(); });
    document.body.append(dlg); dlg.showModal();
    return { dlg, close };
  }
  function askText(title, label, { required = true, placeholder = '' } = {}) {
    return new Promise((resolve) => {
      const input = h('textarea', { rows: 3, maxlength: 300, placeholder });
      const err = h('p', { class: 'err' });
      let done = false;
      const finish = (v) => { if (!done) { done = true; resolve(v); } };
      const body = h('div', { class: 'dlg-body' }, h('label', { class: 'field' }, h('span', { text: label }), input), err);
      const ok = h('button', { class: 'btn', type: 'button', text: 'Continue', on: { click: () => { const v = input.value.trim(); if (required && !v) { err.textContent = 'This field is required.'; return; } finish(v); m.close(); } } });
      const m = modal(title, body, h('div', { class: 'dlg-foot' }, h('button', { class: 'btn ghost', type: 'button', text: 'Cancel', on: { click: () => m.close() } }), ok));
      m.dlg.addEventListener('close', () => finish(null));
      input.focus();
    });
  }
  function confirmDlg(title, message, action = 'Delete') {
    return new Promise((resolve) => {
      let done = false;
      const finish = (v) => { if (!done) { done = true; resolve(v); } };
      const m = modal(title, h('div', { class: 'dlg-body' }, h('p', { text: message })), h('div', { class: 'dlg-foot' },
        h('button', { class: 'btn ghost', type: 'button', text: 'Cancel', on: { click: () => m.close() } }),
        h('button', { class: 'btn bad', type: 'button', text: action, on: { click: () => { finish(true); m.close(); } } })));
      m.dlg.addEventListener('close', () => finish(false));
    });
  }

  // ---------- login ----------
  function showLogin() {
    stopPolling();
    const err = h('div', { class: 'form-error', hidden: true, role: 'alert' });
    const form = h('form', { on: { submit: async (e) => {
      e.preventDefault(); err.hidden = true;
      const btn = form.querySelector('button'); btn.disabled = true;
      try { await api('/login', { method: 'POST', json: { username: form.elements.username.value, password: form.elements.password.value } }); boot(); }
      catch (ex) { err.textContent = ex.message; err.hidden = false; btn.disabled = false; form.elements.password.value = ''; form.elements.password.focus(); }
    } } },
      h('div', {}, h('h1', { text: 'Admin sign in' }), h('p', { class: 'muted', text: 'Only the shop owner can manage products and orders.' })),
      h('label', { class: 'field' }, h('span', { text: 'Username' }), h('input', { name: 'username', autocomplete: 'username', required: true })),
      h('label', { class: 'field' }, h('span', { text: 'Password' }), h('input', { name: 'password', type: 'password', autocomplete: 'current-password', required: true })),
      err, h('button', { class: 'btn', type: 'submit', text: 'Sign in' }));
    $('#app').replaceChildren(h('div', { class: 'login' }, form));
    form.elements.username.focus();
  }

  // ---------- shell ----------
  let pollTimer = null;
  const stopPolling = () => { clearInterval(pollTimer); pollTimer = null; };
  const NAV = [['overview', 'Overview'], ['products', 'Products'], ['orders', 'Orders'], ['sales', 'Sales'], ['settings', 'Settings']];
  let username = '';

  async function boot() {
    try { ({ username } = await api('/me')); } catch (e) { if (!(e instanceof AuthError)) showLogin(); return; }
    const side = h('aside', { class: 'side', id: 'side' },
      h('div', { class: 'logo' }, 'Admin', h('small', { text: `Signed in as ${username}` })),
      NAV.map(([k, label]) => h('a', { href: `#/${k}`, 'data-nav': k, on: { click: () => side.classList.remove('open') } }, h('span', { text: label }), k === 'orders' ? h('span', { class: 'pill', id: 'orderPill', hidden: true }) : null)),
      h('div', { class: 'grow' }),
      h('a', { href: '/', target: '_blank', rel: 'noopener', text: 'View shop ↗' }),
      h('a', { href: '#', text: 'Switch theme', on: { click: (e) => { e.preventDefault(); const n = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'; document.documentElement.setAttribute('data-theme', n); try { localStorage.setItem('theme', n); } catch { /* ignore */ } } } }),
      h('a', { href: '#', text: 'Sign out', on: { click: guard(async (e) => { e.preventDefault(); await api('/logout', { method: 'POST' }); showLogin(); }) } }));
    const mbar = h('div', { class: 'mbar' }, h('strong', { text: 'Admin' }), h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Open menu', text: '☰', on: { click: () => side.classList.toggle('open') } }));
    $('#app').replaceChildren(h('div', { class: 'shell' }, side, h('div', {}, mbar, h('main', { class: 'content', id: 'content' }))));
    if (!location.hash) location.hash = '#/overview';
    route();
    stopPolling(); pollTimer = setInterval(() => { if (!document.hidden) pollBadge(); }, 30000);
    pollBadge();
  }
  async function pollBadge() {
    try {
      const s = await api('/stats');
      const pill = $('#orderPill'); if (!pill) return;
      pill.textContent = s.needs_verification; pill.hidden = s.needs_verification === 0;
      pill.title = `${s.needs_verification} payment${s.needs_verification === 1 ? '' : 's'} to verify`;
    } catch { /* ignore */ }
  }
  window.addEventListener('hashchange', () => { if ($('#content')) route(); });

  async function route() {
    const name = (location.hash.replace(/^#\//, '') || 'overview').split('?')[0];
    const key = NAV.some(([k]) => k === name) ? name : 'overview';
    document.querySelectorAll('[data-nav]').forEach((a) => (a.dataset.nav === key ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current')));
    document.title = `${NAV.find(([k]) => k === key)[1]} · Admin`;
    const c = $('#content');
    c.replaceChildren(h('p', { class: 'muted', text: 'Loading…' }));
    const views = { overview: vOverview, products: vProducts, orders: vOrders, sales: vSales, settings: vSettings };
    try { const el = await views[key](); if (location.hash.includes(key) || key === 'overview') c.replaceChildren(el); }
    catch (e) { if (!(e instanceof AuthError)) c.replaceChildren(h('p', { class: 'form-error', text: e.message })); }
  }

  // ---------- overview ----------
  async function vOverview() {
    const s = await api('/stats');
    const stat = (label, value, sub, cls = '') => h('div', { class: `stat ${cls}` }, h('span', { class: 'muted', text: label }), h('span', { class: 'v', text: value }), sub ? h('span', { class: 'sub', text: sub }) : null);
    return h('div', {},
      h('div', { class: 'page-head' }, h('h1', { text: 'Overview' }), h('a', { class: 'btn', href: '#/products', text: 'Add product' })),
      h('div', { class: 'stats' },
        stat('Total revenue', peso(s.total_revenue), 'Paid and completed orders', 'hero'),
        stat('Total sales', s.total_sales, 'Orders with verified payment'),
        stat('Total orders', s.total_orders),
        stat('Pending payments', s.pending_payments, s.needs_verification ? `${s.needs_verification} waiting for your check` : 'Nothing to verify'),
        stat('Confirmed payments', s.confirmed_payments, 'Paid, not yet completed'),
        stat('Completed orders', s.completed_orders),
        stat('Products', s.products, 'In your catalog')),
      h('section', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', { text: 'Recent transactions' }), h('a', { class: 'btn ghost small', href: '#/orders', text: 'All orders' })),
        s.recent.length ? orderTable(s.recent, true) : h('p', { class: 'empty', text: 'No orders yet. When a customer checks out, it shows up here.' })));
  }

  function orderTable(rows, simple) {
    return h('div', { class: 'table-wrap' }, h('table', {},
      h('thead', {}, h('tr', {}, ['Order', 'Customer', 'Method', 'Status', 'Date'].map((t) => h('th', { text: t })), h('th', { class: 'num', text: 'Total' }))),
      h('tbody', {}, rows.map((o) => h('tr', { class: 'click', tabindex: '0', on: { click: () => openOrder(o.id), keydown: (e) => { if (e.key === 'Enter') openOrder(o.id); } } },
        h('td', {}, h('strong', { text: o.code })), h('td', { text: o.customer_name }), h('td', { text: o.payment_method_label || o.payment_method }),
        h('td', {}, h('span', { class: `badge ${SC[o.status]}`, text: o.status })), h('td', { text: fmtDate(o.created_at) }), h('td', { class: 'num', text: peso(o.total) }))))));
  }

  // ---------- products ----------
  let categories = [];
  async function loadCategories() { ({ categories } = await api('/categories')); }

  async function vProducts() {
    const [{ products }] = await Promise.all([api('/products'), loadCategories()]);
    const wrap = h('div');
    let q = '', cat = '';
    const list = h('div', { class: 'pgrid' });

    async function reload() { const r = await api('/products'); products.splice(0, products.length, ...r.products); paint(); }
    function paint() {
      const rows = products.filter((p) => (!cat || String(p.category_id) === cat) && (!q || (p.name + ' ' + p.description).toLowerCase().includes(q)));
      list.replaceChildren(...(rows.length ? rows.map(pcard) : [h('p', { class: 'empty', style: 'grid-column:1/-1', text: products.length ? 'No products match.' : 'No products yet. Add your first design and it appears in the shop right away.' })]));
    }
    function pcard(p) {
      return h('article', { class: 'pcard' },
        h('div', { class: 'pic' }, p.images[0] ? h('img', { src: p.images[0].url, alt: p.name, loading: 'lazy' }) : null),
        h('div', { class: 'body' }, h('h3', { text: p.name }), h('p', { class: 'muted', text: p.category || 'No category' }), h('p', { class: 'price', text: peso(p.price) }),
          h('div', { class: 'row' }, h('span', { class: `badge ${p.published ? 's-on' : 's-draft'}`, text: p.published ? 'Published' : 'Draft' }), h('span', { class: `badge ${p.available ? 's-on' : 's-off'}`, text: p.available ? 'Available' : 'Unavailable' }))),
        h('div', { class: 'acts' },
          h('button', { class: 'btn ghost small', type: 'button', text: 'Edit', on: { click: () => editProduct(p, reload) } }),
          h('button', { class: 'btn ghost small', type: 'button', text: p.published ? 'Unpublish' : 'Publish', on: { click: guard(async () => { await api(`/products/${p.id}`, { method: 'PUT', form: productForm({ ...p, published: !p.published }) }); toast(p.published ? 'Unpublished' : 'Published. It is live in the shop.'); reload(); }) } }),
          h('button', { class: 'btn ghost small', type: 'button', text: 'Delete', on: { click: guard(async () => { if (await confirmDlg('Delete product', `Delete “${p.name}”? Past orders keep their record of it.`)) { await api(`/products/${p.id}`, { method: 'DELETE' }); toast('Deleted'); reload(); } }) } })));
    }
    const search = h('input', { type: 'search', placeholder: 'Search products', 'aria-label': 'Search products', on: { input: (e) => { q = e.target.value.toLowerCase(); paint(); } } });
    const catSel = h('select', { 'aria-label': 'Filter by category', on: { change: (e) => { cat = e.target.value; paint(); } } }, h('option', { value: '', text: 'All categories' }), categories.map((c) => h('option', { value: c.id, text: `${c.name} (${c.count})` })));
    wrap.append(h('div', { class: 'page-head' }, h('h1', { text: 'Products' }), h('button', { class: 'btn', type: 'button', text: 'Add product', on: { click: () => editProduct(null, reload) } })), h('div', { class: 'filters' }, search, catSel), list);
    paint();
    return wrap;
  }

  function productForm(p, files = []) {
    const fd = new FormData();
    fd.set('name', p.name); fd.set('description', p.description || ''); fd.set('price', p.price);
    fd.set('category_id', p.category_id == null ? '' : p.category_id);
    fd.set('published', p.published ? 'true' : 'false'); fd.set('available', p.available ? 'true' : 'false');
    fd.set('delivery_url', p.delivery_url || '');
    files.forEach((f) => fd.append('images', f));
    return fd;
  }

  function editProduct(product, onSaved) {
    let current = product ? { ...product, images: [...product.images] } : { name: '', description: '', price: '', category_id: null, published: true, available: true, delivery_url: '', images: [] };
    let newFiles = [];
    const err = h('div', { class: 'form-error', hidden: true, role: 'alert' });
    const fieldErr = (n) => h('span', { class: 'err', 'data-err': n });
    const name = h('input', { name: 'name', value: current.name, maxlength: 120, required: true });
    const price = h('input', { name: 'price', type: 'number', min: 0, step: '0.01', inputmode: 'decimal', value: current.price, placeholder: '0.00' });
    const desc = h('textarea', { name: 'description', rows: 4, maxlength: 4000, text: current.description });
    const catSel = h('select', { name: 'category_id' });
    const fillCats = (sel) => catSel.replaceChildren(h('option', { value: '', text: 'No category' }), ...categories.map((c) => h('option', { value: c.id, text: c.name, selected: String(sel) === String(c.id) })));
    fillCats(current.category_id);
    const delivery = h('input', { name: 'delivery_url', type: 'url', value: current.delivery_url, placeholder: 'https://drive.google.com/…', maxlength: 500 });
    const published = h('input', { type: 'checkbox', checked: current.published });
    const available = h('input', { type: 'checkbox', checked: current.available });
    const fileInput = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', multiple: true });
    const gallery = h('div', { class: 'imgs' });

    function paintImages() {
      gallery.replaceChildren(
        ...current.images.map((im, i) => h('div', { class: `im${i === 0 ? ' cover' : ''}` }, h('img', { src: im.url, alt: '' }),
          h('button', { class: 'x', type: 'button', 'aria-label': 'Remove image', text: '✕', on: { click: guard(async () => { const r = await api(`/products/${current.id}/images/${im.id}`, { method: 'DELETE' }); current.images = r.product.images; paintImages(); onSaved(); }) } }),
          i === 0 ? h('span', { class: 'tagc', text: 'Cover' }) : h('button', { class: 'c', type: 'button', text: 'Make cover', on: { click: guard(async () => { const r = await api(`/products/${current.id}/images/${im.id}/cover`, { method: 'POST' }); current.images = r.product.images; paintImages(); onSaved(); }) } }))),
        ...newFiles.map((f, i) => { const url = URL.createObjectURL(f); return h('div', { class: 'im' }, h('img', { src: url, alt: '', on: { load: () => URL.revokeObjectURL(url) } }), h('button', { class: 'x', type: 'button', 'aria-label': 'Remove', text: '✕', on: { click: () => { newFiles.splice(i, 1); paintImages(); } } }), h('span', { class: 'tagc', text: 'New' })); }));
    }
    fileInput.addEventListener('change', () => {
      for (const f of fileInput.files) {
        if (f.size > 8 * 1024 * 1024) { toast(`${f.name} is over 8 MB`, true); continue; }
        newFiles.push(f);
      }
      fileInput.value = ''; paintImages();
    });
    paintImages();

    const body = h('div', { class: 'dlg-body' },
      h('label', { class: 'field' }, h('span', { text: 'Product name' }), name, fieldErr('name')),
      h('div', { class: 'two' },
        h('label', { class: 'field' }, h('span', { text: 'Price (PHP)' }), price, fieldErr('price')),
        h('div', { class: 'field' }, h('label', { for: 'catsel', style: 'font-weight:500;font-size:.9rem', text: 'Category' }), h('div', { style: 'display:flex;gap:8px' }, Object.assign(catSel, { id: 'catsel' }),
          h('button', { class: 'btn ghost small', type: 'button', style: 'height:42px;white-space:nowrap', text: 'New', on: { click: guard(async () => {
            const n = await askText('New category', 'Category name', { placeholder: 'e.g. Wedding invites' }); if (!n) return;
            const r = await api('/categories', { method: 'POST', json: { name: n } }); await loadCategories(); fillCats(r.category.id); toast('Category added');
          }) } })), fieldErr('category_id'))),
      h('label', { class: 'field' }, h('span', { text: 'Description' }), desc),
      h('div', { class: 'field' }, h('span', { style: 'font-weight:500;font-size:.9rem', text: 'Images and previews' }), gallery,
        h('label', { class: 'btn ghost small', style: 'width:fit-content;cursor:pointer' }, '+ Add images', Object.assign(fileInput, { style: 'display:none' })),
        h('small', { class: 'muted', text: 'JPG, PNG or WebP, up to 8 MB each. The first image is the cover.' })),
      h('label', { class: 'field' }, h('span', {}, 'Download link ', h('small', { text: '(optional)' })), delivery, h('small', { class: 'muted', text: 'Customers see it only after you mark their payment as paid. Use a private cloud link.' }), fieldErr('delivery_url')),
      h('div', { style: 'display:grid;gap:10px' },
        h('label', { class: 'check' }, published, 'Published: visible in the shop'),
        h('label', { class: 'check' }, available, 'Available: customers can buy it')),
      err);

    const save = h('button', { class: 'btn', type: 'button', text: product ? 'Save changes' : 'Publish product' });
    const m = modal(product ? 'Edit product' : 'Add product', body, h('div', { class: 'dlg-foot' }, h('button', { class: 'btn ghost', type: 'button', text: 'Cancel', on: { click: () => m.close() } }), save), { wide: true });
    save.addEventListener('click', async () => {
      err.hidden = true; body.querySelectorAll('.err').forEach((x) => { x.textContent = ''; });
      save.disabled = true; save.textContent = 'Saving…';
      try {
        const fd = productForm({ name: name.value, description: desc.value, price: price.value, category_id: catSel.value, published: published.checked, available: available.checked, delivery_url: delivery.value }, newFiles);
        const r = await api(product ? `/products/${product.id}` : '/products', { method: product ? 'PUT' : 'POST', form: fd });
        if (r.images && r.images.rejected) toast(`${r.images.rejected} image(s) were skipped (wrong type or limit reached).`, true);
        toast(product ? 'Saved. The shop is updated.' : (r.product.published ? 'Published. It is live in the shop.' : 'Saved as a draft.'));
        m.close(); onSaved();
      } catch (e) {
        if (e instanceof AuthError) return;
        const span = e.field && body.querySelector(`[data-err="${e.field}"]`);
        if (span) span.textContent = e.message; else { err.textContent = e.message; err.hidden = false; }
        save.disabled = false; save.textContent = product ? 'Save changes' : 'Publish product';
      }
    });
    name.focus();
  }

  // ---------- orders ----------
  async function vOrders() {
    let status = '', q = '', timer;
    const box = h('div');
    const results = h('div', { class: 'card' });
    async function load() {
      const r = await api(`/orders?status=${encodeURIComponent(status)}&q=${encodeURIComponent(q)}`);
      results.replaceChildren(r.orders.length ? orderTable(r.orders) : h('p', { class: 'empty', text: status || q ? 'No orders match these filters.' : 'No orders yet.' }));
    }
    window.__reloadOrders = guard(load);
    const sel = h('select', { 'aria-label': 'Filter by status', on: { change: (e) => { status = e.target.value; guard(load)(); } } }, h('option', { value: '', text: 'All statuses' }), STATUSES.map((s) => h('option', { value: s, text: s })));
    const search = h('input', { type: 'search', placeholder: 'Search code, name, email or reference', 'aria-label': 'Search orders', style: 'max-width:340px', on: { input: (e) => { clearTimeout(timer); timer = setTimeout(() => { q = e.target.value.trim(); guard(load)(); }, 250); } } });
    box.append(h('div', { class: 'page-head' }, h('h1', { text: 'Orders' })), h('div', { class: 'filters' }, sel, search), results);
    await load();
    return box;
  }

  async function openOrder(id) {
    let o;
    try { ({ order: o } = await api(`/orders/${id}`)); } catch (e) { if (!(e instanceof AuthError)) toast(e.message, true); return; }
    const body = h('div', { class: 'dlg-body' });
    const foot = h('div', { class: 'dlg-foot' });
    const m = modal(`Order ${o.code}`, body, foot, { wide: true });

    async function setStatus(status, note) {
      const r = await api(`/orders/${o.id}/status`, { method: 'POST', json: { status, note } });
      o = r.order; toast(`Order marked ${status}`); paint();
      if (window.__reloadOrders && location.hash.startsWith('#/orders')) window.__reloadOrders();
      pollBadge();
    }
    function paint() {
      body.replaceChildren(
        h('div', { style: 'display:flex;gap:12px;align-items:center;flex-wrap:wrap' }, h('span', { class: `badge ${SC[o.status]}`, text: o.status }), h('span', { class: 'muted', text: `Placed ${fmtDate(o.created_at)}` })),
        o.status === 'Payment Verification' ? h('div', { class: 'form-error', style: 'background:color-mix(in srgb,var(--warn) 14%,var(--surface));color:var(--warn);border-color:var(--warn)', text: `Check that ${peso(o.total)} arrived in your ${o.payment_method_label} account and that the reference number matches the receipt.` }) : null,
        h('div', { class: 'two' },
          h('section', {}, h('h3', { style: 'margin-bottom:8px', text: 'Customer' }), h('dl', { class: 'kv' },
            h('dt', { text: 'Name' }), h('dd', { text: o.customer_name }), h('dt', { text: 'Email' }), h('dd', {}, h('a', { href: `mailto:${o.email}`, text: o.email })),
            h('dt', { text: 'Contact' }), h('dd', { text: o.phone }), o.notes ? [h('dt', { text: 'Notes' }), h('dd', { text: o.notes })] : null)),
          h('section', {}, h('h3', { style: 'margin-bottom:8px', text: 'Payment' }), h('dl', { class: 'kv' },
            h('dt', { text: 'Method' }), h('dd', { text: o.payment_method_label }), h('dt', { text: 'Reference' }), h('dd', { text: o.reference_number || 'Not submitted yet' }),
            h('dt', { text: 'Total' }), h('dd', {}, h('strong', { text: peso(o.total) })), o.paid_at ? [h('dt', { text: 'Verified' }), h('dd', { text: fmtDate(o.paid_at) })] : null,
            o.reject_reason ? [h('dt', { text: 'Rejected for' }), h('dd', { text: o.reject_reason })] : null))),
        h('section', {}, h('h3', { style: 'margin-bottom:8px', text: 'Items' }), h('div', { class: 'table-wrap' }, h('table', {}, h('tbody', {}, o.items.map((i) => h('tr', {}, h('td', { text: i.name }), h('td', { class: 'num', text: peso(i.price) }))))))),
        o.has_receipt ? h('section', {}, h('h3', { style: 'margin-bottom:8px', text: 'Payment receipt' }),
          h('a', { href: `/admin/api/orders/${o.id}/receipt?t=${Date.parse(o.updated_at)}`, target: '_blank', rel: 'noopener' }, h('img', { class: 'receipt', src: `/admin/api/orders/${o.id}/receipt?t=${Date.parse(o.updated_at)}`, alt: 'Customer payment receipt' })))
          : h('p', { class: 'muted', text: 'No receipt uploaded yet.' }),
        h('section', {}, h('h3', { style: 'margin-bottom:8px', text: 'History' }), h('ul', { class: 'timeline' }, o.events.slice().reverse().map((e) => h('li', {}, h('span', { text: fmtDate(e.created_at) }), h('span', {}, h('strong', { text: e.status }), e.note ? ` · ${e.note}` : ''))))));

      const run = (fn) => guard(async () => { await fn(); });
      const btns = [];
      if (['Payment Verification', 'Pending Payment', 'Rejected'].includes(o.status)) btns.push(h('button', { class: 'btn ok', type: 'button', text: 'Approve payment', on: { click: run(async () => { if (await confirmDlg('Approve payment', `Confirm that you received ${peso(o.total)} via ${o.payment_method_label}? This counts toward your revenue.`, 'Approve')) await setStatus('Paid'); }) } }));
      if (['Payment Verification', 'Pending Payment', 'Paid'].includes(o.status)) btns.push(h('button', { class: 'btn bad', type: 'button', text: 'Reject payment', on: { click: run(async () => { const r = await askText('Reject payment', 'Reason (the customer will see this)', { placeholder: 'e.g. The amount received was lower than the total.' }); if (r) await setStatus('Rejected', r); }) } }));
      if (o.status === 'Paid') btns.push(h('button', { class: 'btn', type: 'button', text: 'Mark completed', on: { click: run(() => setStatus('Completed')) } }));
      if (!['Cancelled', 'Completed'].includes(o.status)) btns.push(h('button', { class: 'btn ghost', type: 'button', text: 'Cancel order', on: { click: run(async () => { if (await confirmDlg('Cancel order', 'Cancel this order? The customer will see it as cancelled.', 'Cancel order')) await setStatus('Cancelled'); }) } }));
      const sel = h('select', { 'aria-label': 'Set status', style: 'width:auto' }, STATUSES.map((s) => h('option', { value: s, text: s, selected: s === o.status })));
      foot.replaceChildren(h('div', { class: 'actions', style: 'margin-right:auto' }, sel, h('button', { class: 'btn ghost small', type: 'button', text: 'Set status', on: { click: run(async () => { if (sel.value === 'Rejected') { const r = await askText('Reject payment', 'Reason (the customer will see this)'); if (r) await setStatus('Rejected', r); } else await setStatus(sel.value); }) } })), ...btns);
    }
    paint();
  }

  // ---------- sales ----------
  async function vSales() {
    const s = await api('/sales');
    let period = 'daily';
    const chartBox = h('div');
    const fmtKey = (k) => {
      if (period === 'monthly') return new Date(k + '-01T00:00:00Z').toLocaleDateString('en-PH', { month: 'short', year: '2-digit', timeZone: 'UTC' });
      return new Date(k + 'T00:00:00Z').toLocaleDateString('en-PH', { month: 'short', day: 'numeric', timeZone: 'UTC' });
    };
    function chart() {
      const data = s[period];
      const W = 720, H = 240, pl = 8, pb = 26, pt = 16;
      const max = Math.max(1, ...data.map((d) => d.revenue));
      const bw = (W - pl * 2) / data.length;
      const every = Math.ceil(data.length / 8);
      const root = svg('svg', { class: 'chart', viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': `${period} revenue, highest ${peso(max)}`, preserveAspectRatio: 'none' });
      for (let i = 0; i <= 3; i++) { const y = pt + ((H - pb - pt) * i) / 3; root.append(svg('line', { x1: 0, x2: W, y1: y, y2: y })); }
      data.forEach((d, i) => {
        const bh = ((H - pb - pt) * d.revenue) / max;
        const x = pl + i * bw + bw * 0.14;
        const r = svg('rect', { class: 'bar', x, y: H - pb - bh, width: bw * 0.72, height: Math.max(d.revenue ? 2 : 0, bh), rx: 3 }, svg('title', {}, `${fmtKey(d.key)}: ${peso(d.revenue)} from ${d.orders} order${d.orders === 1 ? '' : 's'}`));
        root.append(r);
        if (i % every === 0) root.append(svg('text', { x: x + bw * 0.36, y: H - 8, 'text-anchor': 'middle' }, fmtKey(d.key)));
      });
      const total = data.reduce((a, d) => a + d.revenue, 0);
      chartBox.replaceChildren(h('p', { class: 'muted', style: 'margin-bottom:8px', text: `${peso(total)} over this period. Highest: ${peso(max === 1 && total === 0 ? 0 : max)}.` }), root);
    }
    const tabs = h('div', { class: 'tabs', role: 'group', 'aria-label': 'Period' }, [['daily', 'Daily'], ['weekly', 'Weekly'], ['monthly', 'Monthly']].map(([k, l]) => h('button', { type: 'button', 'aria-pressed': String(k === period), text: l, on: { click: (e) => { period = k; tabs.querySelectorAll('button').forEach((b) => b.setAttribute('aria-pressed', String(b === e.currentTarget))); chart(); } } })));
    chart();

    const maxM = Math.max(1, ...s.by_method.map((m) => m.revenue));
    const from = h('input', { type: 'date', 'aria-label': 'From date', style: 'width:auto' });
    const to = h('input', { type: 'date', 'aria-label': 'To date', style: 'width:auto' });
    const exportBtn = h('a', { class: 'btn small', href: '/admin/api/sales/export.csv', text: 'Download CSV report' });
    const upd = () => { const p = new URLSearchParams(); if (from.value) p.set('from', from.value); if (to.value) p.set('to', to.value); exportBtn.href = '/admin/api/sales/export.csv?' + p; };
    from.addEventListener('change', upd); to.addEventListener('change', upd);

    return h('div', {},
      h('div', { class: 'page-head' }, h('h1', { text: 'Sales' })),
      h('div', { class: 'stats' },
        h('div', { class: 'stat hero' }, h('span', { class: 'muted', text: 'Total revenue' }), h('span', { class: 'v', text: peso(s.total_revenue) }), h('span', { class: 'sub muted', text: `${s.total_sales} verified sale${s.total_sales === 1 ? '' : 's'}` })),
        h('div', { class: 'stat' }, h('span', { class: 'muted', text: 'Today' }), h('span', { class: 'v', text: peso(s.today) })),
        h('div', { class: 'stat' }, h('span', { class: 'muted', text: 'This month' }), h('span', { class: 'v', text: peso(s.this_month) }))),
      h('div', { class: 'cols' },
        h('section', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', { text: 'Revenue' }), tabs), chartBox),
        h('section', { class: 'card' }, h('h2', { style: 'margin-bottom:14px', text: 'By payment method' }), h('div', { class: 'meter' }, s.by_method.map((m) => h('div', { class: 'm' },
          h('div', { class: 'mh' }, h('span', { text: m.method }), h('span', { text: peso(m.revenue) })),
          h('div', { class: 'track' }, h('div', { class: 'fill', style: `width:${(m.revenue / maxM) * 100}%` })), h('small', { class: 'muted', text: `${m.orders} order${m.orders === 1 ? '' : 's'}` })))))),
      h('section', { class: 'card' }, h('h2', { style: 'margin-bottom:10px', text: 'Best sellers' }),
        s.top_products.length ? h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, h('tr', {}, h('th', { text: 'Design' }), h('th', { class: 'num', text: 'Sold' }), h('th', { class: 'num', text: 'Revenue' }))), h('tbody', {}, s.top_products.map((p) => h('tr', {}, h('td', { text: p.name }), h('td', { class: 'num', text: p.sold }), h('td', { class: 'num', text: peso(p.revenue) })))))) : h('p', { class: 'empty', text: 'Best sellers show up after your first verified sale.' })),
      h('section', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', { text: 'Transaction history' }), h('div', { class: 'actions' }, from, to, exportBtn)),
        s.history.length ? h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Paid on', 'Order', 'Customer', 'Method', 'Reference'].map((t) => h('th', { text: t })), h('th', { class: 'num', text: 'Total' }))),
          h('tbody', {}, s.history.map((t) => h('tr', { class: 'click', on: { click: () => openOrder(t.id) } }, h('td', { text: fmtDate(t.paid_at) }), h('td', {}, h('strong', { text: t.code })), h('td', { text: t.customer_name }), h('td', { text: t.payment_method }), h('td', { text: t.reference_number || '–' }), h('td', { class: 'num', text: peso(t.total) })))))) : h('p', { class: 'empty', text: 'No verified payments yet.' })));
  }

  // ---------- settings ----------
  async function vSettings() {
    const s = await api('/settings');
    const err = h('div', { class: 'form-error', hidden: true, role: 'alert' });
    const fld = (label, el, hint) => h('label', { class: 'field' }, h('span', {}, label, hint ? h('small', { text: ` ${hint}` }) : null), el);
    const shop = { shop_name: h('input', { value: s.shop_name, maxlength: 60 }), tagline: h('input', { value: s.tagline, maxlength: 160 }), about: h('textarea', { rows: 4, maxlength: 1200, text: s.about }), contact_email: h('input', { type: 'email', value: s.contact_email, maxlength: 160 }) };
    const pay = {};
    const payCards = Object.entries(s.payments).map(([k, p]) => {
      pay[k] = { account_name: h('input', { value: p.account_name, maxlength: 80 }), account_number: h('input', { value: p.account_number, maxlength: 40 }), instructions: h('textarea', { rows: 3, maxlength: 600, text: p.instructions }) };
      const qr = h('div', { class: 'imgs' });
      const paintQr = (url) => qr.replaceChildren(url ? h('div', { class: 'im' }, h('img', { src: url, alt: `${p.label} QR` })) : h('span', { class: 'muted', text: 'No QR code yet' }));
      paintQr(p.qr_url);
      const file = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', style: 'display:none', on: { change: guard(async () => { if (!file.files[0]) return; const fd = new FormData(); fd.set('qr', file.files[0]); const r = await api(`/settings/qr/${k}`, { method: 'POST', form: fd }); paintQr(r.qr_url); toast('QR code updated'); }) } });
      return h('section', { class: 'card' }, h('h2', { style: 'margin-bottom:14px', text: p.label }),
        h('div', { style: 'display:grid;gap:14px' }, h('div', { class: 'two' }, fld('Account name', pay[k].account_name), fld('Account number', pay[k].account_number)), fld('Payment instructions', pay[k].instructions, '(one step per line)'),
          h('div', { class: 'field' }, h('span', { style: 'font-weight:500;font-size:.9rem', text: 'QR code (optional)' }), qr, h('div', { class: 'actions' }, h('label', { class: 'btn ghost small', style: 'cursor:pointer' }, 'Upload QR', file),
            p.qr_url ? h('button', { class: 'btn ghost small', type: 'button', text: 'Remove', on: { click: guard(async () => { await api(`/settings/qr/${k}`, { method: 'DELETE' }); paintQr(''); toast('QR code removed'); }) } }) : null))));
    });
    const saveBtn = h('button', { class: 'btn', type: 'button', text: 'Save settings', on: { click: async () => {
      err.hidden = true;
      try {
        await api('/settings', { method: 'PUT', json: { shop_name: shop.shop_name.value, tagline: shop.tagline.value, about: shop.about.value, contact_email: shop.contact_email.value, payments: Object.fromEntries(Object.entries(pay).map(([k, f]) => [k, { account_name: f.account_name.value, account_number: f.account_number.value, instructions: f.instructions.value }])) } });
        toast('Settings saved. The shop is updated.');
      } catch (e) { if (!(e instanceof AuthError)) { err.textContent = e.message; err.hidden = false; } }
    } } });

    const cur = h('input', { type: 'password', autocomplete: 'current-password' }); const nw = h('input', { type: 'password', autocomplete: 'new-password', minlength: 10 });
    const pwBtn = h('button', { class: 'btn ghost', type: 'button', text: 'Change password', on: { click: guard(async () => { await api('/password', { method: 'POST', json: { current: cur.value, next: nw.value } }); cur.value = ''; nw.value = ''; toast('Password changed'); }) } });

    return h('div', {},
      h('div', { class: 'page-head' }, h('h1', { text: 'Settings' }), saveBtn),
      h('section', { class: 'card' }, h('h2', { style: 'margin-bottom:14px', text: 'Shop' }), h('div', { style: 'display:grid;gap:14px' }, fld('Shop name', shop.shop_name), fld('Headline', shop.tagline, '(shown on the home page)'), fld('About', shop.about), fld('Contact email', shop.contact_email))),
      h('div', { style: 'margin-top:20px;display:grid;gap:20px' }, payCards), h('div', { style: 'margin-top:14px' }, err),
      h('section', { class: 'card' }, h('h2', { style: 'margin-bottom:14px', text: 'Password' }), h('div', { class: 'two' }, fld('Current password', cur), fld('New password', nw, '(10+ characters)')), h('div', { style: 'margin-top:14px' }, pwBtn)));
  }

  boot();
})();
